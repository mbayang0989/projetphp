<?php

// Connexion à la BDD

require_once("Connexion.php");
$bdd= bd_connect();

$id_stagere=$_POST['id_stagere'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$departement=$_POST['departement'];
$debut_stage=$_POST['debut_stage'];
$fin_stage=$_POST['fin_stage']; 
$civilite=$_POST['civilite'];
$niveau=$_POST['niveau']; 

//traitement du Submit

if(isset($_POST['valider']))
{
 
  $sql =$bdd->prepare("UPDATE stagere
       SET Nom_stage='$nom',
           Prenom_stage='$prenom',
           Email_stage='$email',
           Departement_stage='$departement',
           Debut_stage='$debut_stage',
           fin_stage='$fin_stage',
           civilite_stage='$civilite',
           niveau_stage='$niveau'
      WHERE id_stagere='$id_stagere' ");
  $sql->execute();

  echo "insertion reussi";
}

// var_dump($sql);
header('location: afficherStage.php');
 ?>
 
 