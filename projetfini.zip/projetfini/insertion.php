<?php
session_start();
?>
<?php 
    include('connexion.php');

    $bdd= bd_connect();

    $nom=$_POST['nom'];
    $prenom=$_POST['prenom'];
    $email=$_POST['email'];
    $departement=$_POST['departement'];
    $debut_stage=$_POST['debut_stage'];
    $fin_stage=$_POST['fin_stage']; 
    $civilite=$_POST['civilite'];
    $niveau=$_POST['niveau']; 

  if(isset($_POST['valider']))
  {
    $sql=$bdd->prepare("INSERT INTO stagere(Nom_stage,Prenom_stage,Email_stage,Departement_stage,Debut_stage,Fin_stage,civilite_stage,niveau_stage)
    VALUES ('$nom','$prenom','$email','$departement','$debut_stage','$fin_stage','$civilite','$niveau')");
    $sql->execute();

    echo "insertion reussi";
    // var_dump($sql);
  
    header('location: afficherStage.php');
  }

 ?>