<?php
session_start();
// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
// if(!isset($_SESSION["email"]))
// {
//     // header("Location: authentification.php");
//     exit(); 
//    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"/>
        <title>Formulaire PHP</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    </head>
 <body> 
  <header>
    <div class="" style="height: 900px; width: 1640px; background-image:url(images/bbb.jpg);">
    
        <h1>FORMULAIRE D'ENREGISTREMENT DES STAGIAIRES</h1>
         <td>
        <form action="authentification.php" method="post" class="d-grid gap-2 d-md-flex justify-content-md-end">
           <button name="deconnecter" type ="submit" value="" class="btn btn-danger">DECONNECTER</button> 
           
        </form>
         </td>     
         <form action="insertion.php" method="post">
            <table>
                <tr>
                    <td class="fw-bold">Nom</td>
                    <td><input type="text" name="nom" size="50"></td>
                </tr>
                <tr>
                    <td class="fw-bold">Prenom</td>
                    <td><input  type="text" name="prenom" size="50"></td>
                </tr>
                <tr>
                    <td class="fw-bold">Email</td>
                    <td><input type="text" name="email" size="50"></td>
                </tr>
                <tr>
                    <td class="fw-bold">Departement</td>
                    <td><input type="text" name="departement" size="50"></td>
                </tr>
                <tr>
                    <td class="fw-bold">Debut_stage </td>
                    <td><input type="text" name="debut_stage" size="50"></td>
                </tr>
                <tr>
                    <td class="fw-bold">Fin_stage</td>
                    <td><input type="text" name="fin_stage" size="50"></td>
                </tr>
                <tr>
                    <td rowspan="2" class="fw-bold">civilite</td>
                    <td><input type="radio" name="civilite" value="Homme ">Homme</td>
                </tr>
                <tr>
                    <td><input type="radio" name="civilite" value="Femme ">Femme</td>
                </tr>
                <tr>
                    <td class="fw-bold">Niveau</td>
                    <td><textarea rows="10" name="niveau" cols="60"></textarea></td>
                </tr>
                <tr>
                    <td><input class="btn btn-success" name="valider" type="submit" value="Enrigistrer"></td>
                </tr>
            </table>
            </form>
    </div>  
   </header>
 </body>
</html>
            
   
            
 
            

