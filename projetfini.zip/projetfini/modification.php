<?php
require_once("Connexion.php");
$bdd= bd_connect();


  //var_dump($_POST['modifier']);
  $id_stagere = $_GET['id_stagere'];
?>
  <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8"/>
        <title>Formulaire PHP</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

    </head>
<body>
<header>
    <div class="" style="height:900px; width:1630px; background-image:url(images/tele.jpg);"> 
        <h1>MODIFICATION DES ENREGISTREMENT</h1>
   <form action="modifier.php" method="post">
   <table>
       <tr>
           <td>Nom</td>
           <td><label>
           <input type="text" name="nom" size="50" value=" <?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
  $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
            echo  $requte->Nom_stage;}?>"/>
           </label></td>
       </tr>
       <tr>
           <td>Prenom</td>
           <td><label>
           <input type="text" name="prenom" size="50" value="<?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
  $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
            echo $requte->Prenom_stage; } ?>"/>
           </label></td>
       </tr>
       <tr>
           <td>Email</td>
           <td><label>
           <input type="text" name="email" size="50" value="<?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
  $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
            echo  $requte->Email_stage;} ?>"/>
           </label></td>
       </tr>
       <tr>
           <td>Departement</td>
           <td><label>
           <input type="text" name="departement" size="50" value="<?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
  $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
            echo  $requte->Departement_stage; }?>"/>
           </label></td>
       </tr>
       <tr>
           <td>Debut_stage </td>
           <td><label>
           <input type="text" name="debut_stage" size="50" value="<?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
  $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
            echo  $requte->Debut_stage; }?>"/>
           </label></td>
       </tr>
       <tr>
           <td>Fin_stage</td>
           <td><label>
           <input type="text" name="fin_stage" size="50" value="<?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
  $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
            echo  $requte->Fin_stage; }?>"/>
           </label></td>
       </tr>

       <tr>
           <td rowspan="2">civilite</td>
           <td><label>
             <input type="radio" name="civilite" value="Homme">Homme</label></td>
       </tr>
       <tr>
           <td><label>
             <input type="radio" name="civilite" value="Femme">Femme</label></td>
       </tr>
       <tr>
            <td>niveau</td>
            <td><textarea rows="5" name="niveau" cols="60" ><?php  $req1= $bdd->prepare("SELECT * FROM stagere WHERE id_stagere= '$id_stagere' ");
            $req1->execute(); 
            while($requte=$req1->fetch(PDO::FETCH_OBJ))  {
          echo  $requte->niveau_stage; } ?></textarea></td>
       </tr>
       <input type="hidden" name="id_stagere" value=" <?php echo $id_stagere ?> ">
       <tr>
           <td><input name="valider" type="submit" value="Valider"></td>
       </tr>
   </table>
   </form>
   </div>  
   </header>
 </body>
</html>
  