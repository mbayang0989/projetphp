<?php
 session_start();
 // Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
 if(!isset($_SESSION["username"])){
  header("Location: login.php");
  exit(); 
}
  include('connexion.php');
 $bdd = bd_connect();

 // SUPPRESSION
if(isset($_POST['supprimer']))
{
    //var_dump($_POST['supprimer']);
    $id_stagere = $_POST['supprimer'];
    $req= $bdd->prepare("DELETE FROM stagere WHERE id_stagere= '$id_stagere' ");
    $req->execute(); 
}

$req2=$bdd->prepare('SELECT * FROM stagere');
$req2->execute();

?>
  <td>
    <form action="login.php" method="post" class="d-grid gap-2 d-md-flex justify-content-md-end">
      <button name="deconnecter" type ="submit" value="" class="btn btn-danger"><a href="logout.php">Deconnexion</a></button> 
    </form>
  </td>      
<!-- Affichage des stageres enregistres dans la base de donnee   -->

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<table border="12px" class="table table-bordered">

 <thead>
  <tr>
    <th>id_stagere</th>
    <th>Nom_stage</th>
    <th>Prenom_stage</th>
    <th>Email_stage</th>
    <th>Departement_stage</th>
    <th>Debut_stage</th>
    <th>Fin_stage</th>
    <th>civilite_stage</th>
    <th>niveau_stage</th>
    <th>Action</th>
 </thead>
 <tbody>
   <?php while($requte=$req2->fetch(PDO::FETCH_OBJ))  {?>
    <tr>
     <td><?= $requte->id_stagere ?></td>  
     <td><?= $requte->Nom_stage ?></td>
     <td><?= $requte->Prenom_stage ?></td>
     <td><?= $requte->Email_stage ?></td>
     <td><?= $requte->Departement_stage ?></td>
     <td><?= $requte->Debut_stage ?></td>
     <td><?= $requte->Fin_stage ?></td>
     <td><?= $requte->civilite_stage ?></td>
     <td><?= $requte->niveau_stage ?></td>

      <td>
      <form action="#" method="post">
      
      <button name="modifier" type ="submit" value="<?=$requte->id_stagere?>" class="btn btn-info"><a href="modification.php?id_stagere=<?=$requte->id_stagere?> ">Modifier</a></button> 
      
      <button name="supprimer" type="submit" value="<?=$requte->id_stagere?>" class="btn btn-danger">Supprimer</button> 
      </form>
          </td>
    </tr>
   <?php } ?>
   </tbody> 
</table>





